module.exports = require('tailwindcss-animate')
