module.exports = require('@tailwindcss/typography')
