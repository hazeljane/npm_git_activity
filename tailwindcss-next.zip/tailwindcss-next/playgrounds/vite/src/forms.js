module.exports = require('@tailwindcss/forms')
