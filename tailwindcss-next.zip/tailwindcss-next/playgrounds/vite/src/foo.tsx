import { Bar } from './bar'

export function Foo() {
  return (
    <div>
      <h2 className="text-blue-500">Foo</h2>
      <Bar />
    </div>
  )
}
