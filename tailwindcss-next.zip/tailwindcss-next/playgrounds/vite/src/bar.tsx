export function Bar() {
  return (
    <div>
      <h2 className="text-red-500 underline">Bar</h2>
    </div>
  )
}
