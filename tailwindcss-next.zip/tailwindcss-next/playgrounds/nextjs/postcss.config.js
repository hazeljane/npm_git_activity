import tailwindcss from '@tailwindcss/postcss'

module.exports = {
  plugins: [tailwindcss()],
}
