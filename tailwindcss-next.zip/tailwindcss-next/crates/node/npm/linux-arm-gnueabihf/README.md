# `@tailwindcss/oxide-linux-arm-gnueabihf`

This is the **armv7-unknown-linux-gnueabihf** binary for `@tailwindcss/oxide`
