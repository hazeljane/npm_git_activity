# `@tailwindcss/oxide-linux-arm64-musl`

This is the **aarch64-unknown-linux-musl** binary for `@tailwindcss/oxide`
